export interface IProduct {
  id: number,
  name: string,
  tag: string,
  description: string,
  image: string,
  starrating: number
}
