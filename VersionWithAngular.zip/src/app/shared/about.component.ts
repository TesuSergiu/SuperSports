import { Component } from '@angular/core';

@Component({
  selector: 'about',
  templateUrl:'./app/shared/about.component.html'
})

export class AboutComponent {

}
