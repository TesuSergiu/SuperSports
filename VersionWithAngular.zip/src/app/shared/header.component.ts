import { Component } from '@angular/core';

@Component({
  selector: 'site-header',
  templateUrl:'./app/shared/header.component.html'
})

export class HeaderComponent {

}
