import { IProduct } from '../product/product'

export const PRODUCTDATA:IProduct[] = [{
  id: 1,
  name: 'GEL-FUJITRABUCO 5 G-TX',
  description: `Lorem ipsum dolor sit amet, consectetur adipiscing,
            vivamus congue nulla leo, quis imperdiet magna.....`,
  tag: "RUNNING SHOES",
  image: "app/assets/shoe.png",
  starrating: 4
},
  {
    id: 2,
    name: 'GEL-FUJITRABUCO 6 G-TX',
    description: `Lorem ipsum dolor sit amet, consectetur adipiscing,
            vivamus congue nulla leo, quis imperdiet magna.....`,
    tag: "RUNNING SHOES",
    image: "app/assets/shoe.png",
    starrating: 5
  }];
