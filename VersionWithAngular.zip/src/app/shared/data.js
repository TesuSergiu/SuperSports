"use strict";
exports.PRODUCTDATA = [{
        id: 1,
        name: 'GEL-FUJITRABUCO 5 G-TX',
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing,\n            vivamus congue nulla leo, quis imperdiet magna.....",
        tag: "RUNNING SHOES",
        image: "app/assets/shoe.png",
        starrating: 4
    },
    {
        id: 2,
        name: 'GEL-FUJITRABUCO 6 G-TX',
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing,\n            vivamus congue nulla leo, quis imperdiet magna.....",
        tag: "RUNNING SHOES",
        image: "app/assets/shoe.png",
        starrating: 5
    }];
//# sourceMappingURL=data.js.map