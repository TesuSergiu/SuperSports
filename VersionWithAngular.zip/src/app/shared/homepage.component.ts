import { Component } from '@angular/core';

@Component({
  selector: 'homepage',
  templateUrl:'./app/shared/homepage.component.html'
})

export class HomepageComponent {

}
