import { Component } from '@angular/core';

@Component({
  selector: 'site-footer',
  templateUrl:'./app/shared/footer.component.html'
})

export class FooterComponent {

}
